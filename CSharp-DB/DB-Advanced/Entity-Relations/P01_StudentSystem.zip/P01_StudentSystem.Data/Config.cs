﻿namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string ConnectionString = @"Server=DESKTOP-KBQGTHG\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}
