﻿namespace P01_StudentSystem.Data.Common
{
    public static class GlobalConstants
    {
        //Student
        public const int StudentNameMaxLength = 100;

        //Course
        public const int CourseNameMaxLength = 80;

        //Resource
        public const int ResourceNameMaxLength = 50;
    }
}
